import tkinter as tk
from math import sin, cos, pi

def calculate_and_draw():
    global n, p
    try:
        n = int(entry.get())
        if n < 4:
            label.config(text="Введите n >= 4")
            return
        p = 0
        for i in range(n-1, 1, -1):
            for j in range(i-1, 1, -1):
                if n % j != 0 and i % j != 0:
                    continue
                else:
                    p = i
                    break
        draw_polygon()
    except ValueError:
        label.config(text="Введите корректное число")

def draw_polygon():
    canvas.delete("all")
    x = []
    y = []
    for i in range(1, n + 1):
        x.append(cos((2 * pi * i) / n) * 200 + 300)
        y.append(sin((2 * pi * i) / n) * 200 + 300)
    for i in range(n - 1, -1, -1):
        canvas.create_line(x[i % n], y[i % n], x[(i + p) % n - 1], y[(i + p) % n - 1])

master = tk.Tk()
master.title("Построение полигона")

label = tk.Label(master, text="Введите n:")
label.pack()

entry = tk.Entry(master)
entry.pack()

button = tk.Button(master, text="Рассчитать и нарисовать", command=calculate_and_draw)
button.pack()

canvas = tk.Canvas(master, bg="white", width=600, height=600)
canvas.pack()

n = 0
p = 0

master.mainloop()
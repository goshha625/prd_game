from random import randint, choice 
import tkinter 
 
def draw(event): 
    color = "#" 
    for i in range(6): 
        color += choice("1234567890ABCDEF") 
    x0 = randint(-100, 1000) 
    y0 = randint(-100, 1000) 
    r = randint(-max(x0, y0), max(x0, y0)) 
    canvas.create_oval((x0, x0+r), (y0, y0+r), fill=color) 
 
master = tkinter.Tk() 
canvas = tkinter.Canvas(master, bg="white", width=600, height=600) 
canvas.pack() 
canvas.bind("<KeyPress>", draw) 
canvas.focus_set() 
master.mainloop()
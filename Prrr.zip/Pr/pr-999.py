import tkinter as tk
import random
import pygame
import time

def move_wrap(canvas, obj, move):
    coords = canvas.coords(obj)
    if len(coords) == 2:
        x, y = coords
        new_x = (x + move[0]) % (step * N_X)
        new_y = (y + move[1]) % (step * N_Y)
        canvas.coords(obj, new_x, new_y)
    else:
        x1, y1, x2, y2 = coords
        new_x1 = (x1 + move[0]) % (step * N_X)
        new_y1 = (y1 + move[1]) % (step * N_Y)
        new_x2 = new_x1 + step
        new_y2 = new_y1 + step
        canvas.coords(obj, new_x1, new_y1, new_x2, new_y2)

def check_move():
    global sal_count, stop_moves
    def check_fc(c1, c2):
        min_x1 = c1[0]
        max_x1 = c1[0] + 100
        min_y1 = c1[1]
        max_y1 = c1[1] + 100
        fc2 = [[c2[0], c2[1]], [c2[0]+100, c2[1]+100], [c2[0], c2[1]+100], [c2[0]+100, c2[1]]]
        for i in fc2:
            if min_x1 <= i[0] <= max_x1 and min_y1 <= i[1] <= max_y1:
                return True
        return False

    if check_fc(canvas.coords(player), canvas.coords(exit)):
        label.config(text="ПОБЕДА! ВРЕМЯ ОБЕДА!")
        canvas.create_image((0, 0), image=win_pic, anchor='nw')
        play_music_win()
        master.unbind("<KeyPress>")
        master.bind("<KeyPress>", do_nothing)
        return

    for f in durkas:
        if check_fc(canvas.coords(player), canvas.coords(f)):
            label.config(text="ФАТАЛЬНАЯ ОШИБКА!")
            canvas.create_image((0, 0), image=end_pic, anchor='nw')
            master.update()
            play_music_fail()
            time.sleep(4.5)
            canvas.create_image((0, 0), image=end_pic2, anchor='nw')
            master.unbind("<KeyPress>")
            master.bind("<KeyPress>", prepare_and_start)
            return

    for e in enemies:
        if check_fc(canvas.coords(player), canvas.coords(e[0])):
            label.config(text="")
            canvas.create_image((0, 0), image=end_pic, anchor='nw')
            master.update()
            play_music_fail()
            time.sleep(4)
            canvas.create_image((0, 0), image=end_pic2, anchor='nw')
            master.unbind("<KeyPress>")
            master.bind("<KeyPress>", prepare_and_start)
            return

    for s in sal_list:
        if check_fc(canvas.coords(player), canvas.coords(s)):
            canvas.delete(s)
            sal_list.remove(s)
            sal_count += 1
            sal_label.config(text=f"SAL: {sal_count} (При нажатии пробела враги замрут на 5 ходов и потратиться 1 бонус)")

def key_pressed(event):
    global stop_moves, sal_count
    if event.keysym == 'Up':
        move_wrap(canvas, player, (0, -step))
    elif event.keysym == 'Down':
        move_wrap(canvas, player, (0, step))
    elif event.keysym == 'Left':
        move_wrap(canvas, player, (-step, 0))
    elif event.keysym == 'Right':
        move_wrap(canvas, player, (step, 0))
    elif event.keysym == 'space' and sal_count > 0:
        if sal_count > 0:
            sal_count -= 1
            sal_label.config(text=f"SAL: {sal_count} (При нажатии пробела враги замрут на 5 ходов и потратиться 1 бонус)")
            stop_moves = 5

    check_move()
    if stop_moves > 0:
        stop_moves -= 1
    else:
        for enemy in enemies:
            direction = enemy[1]()
            move_wrap(canvas, enemy[0], direction)

def do_nothing(event):
    pass

def prepare_and_start(event=None):
    global player, exit, durkas, enemies, sal_list, sal_count, stop_moves
    canvas.delete("all")
    def generate_position(existing_positions):
        while True:
            pos = (random.randint(0, N_X - 2) * step, random.randint(0, N_Y - 2) * step)
            if all(abs(pos[0] - ep[0]) > 100 or abs(pos[1] - ep[1]) > 100 for ep in existing_positions):
                return pos

    player_pos = generate_position([])
    player = canvas.create_image(player_pos, image=player_pic, anchor='nw')

    existing_positions = [player_pos]
    exit_pos = generate_position(existing_positions)
    exit = canvas.create_image(exit_pos, image=exit_pic, anchor='nw')
    existing_positions.append(exit_pos)

    N_DURKAS = 2
    durkas = []
    for i in range(N_DURKAS):
        durka_pos = generate_position(existing_positions)
        durka = canvas.create_image(durka_pos, image=durka_pic, anchor='nw')
        durkas.append(durka)
        existing_positions.append(durka_pos)

    N_ENEMIES = 1
    enemies = []
    for i in range(N_ENEMIES):
        enemy_pos = generate_position(existing_positions)
        enemy = canvas.create_image(enemy_pos, image=enemy_pic, anchor='nw')
        enemies.append((enemy, move_to_player(enemy)))
        existing_positions.append(enemy_pos)

    N_SAL = 3
    sal_list = []
    for i in range(N_SAL):
        sal_pos = generate_position(existing_positions)
        sal = canvas.create_image(sal_pos, image=sal_pic, anchor='nw')
        sal_list.append(sal)
        existing_positions.append(sal_pos)

    sal_count = 0
    sal_label.config(text=f"SAL: {sal_count} (При нажатии пробела враги замрут на 5 ходов и потратиться 1 бонус)")
    stop_moves = 0

    label.config(text="БЕГИ!!!")
    master.unbind("<KeyPress>")
    master.bind("<KeyPress>", key_pressed)

def move_to_player(enemy):
    def move_func():
        player_coords = canvas.coords(player)
        enemy_coords = canvas.coords(enemy)
        x_move = 0
        y_move = 0
        if abs(player_coords[0] - enemy_coords[0]) > abs(player_coords[1] - enemy_coords[1]):
            if player_coords[0] > enemy_coords[0]:
                x_move = step
            elif player_coords[0] < enemy_coords[0]:
                x_move = -step
        else:
            if player_coords[1] > enemy_coords[1]:
                y_move = step
            elif player_coords[1] < enemy_coords[1]:
                y_move = -step
        return (x_move, y_move)
    return move_func

def play_music():
    pygame.mixer.music.load("material/Surfers.mp3")
    pygame.mixer.music.play(-1)

def play_music_win():
    pygame.mixer.music.load("material/Win.mp3")
    pygame.mixer.music.play(0)

def play_music_fail():
    pygame.mixer.music.load("material/Fail.mp3")
    pygame.mixer.music.play(0)

master = tk.Tk()
master.title("Побег")

step = 50
N_X = 25
N_Y = 15
canvas = tk.Canvas(master, bg='green', width=step * N_X, height=step * N_Y)
canvas.pack()

label = tk.Label(master, text="Найди выход", font=("Oswald", 20))
label.pack(pady=20, anchor="n")

sal_label = tk.Label(master, text="SAL: 0 (При нажатии пробела враги замрут на 5 ходов и потратиться 1 бонус)", font=("Oswald", 20))
sal_label.pack(pady=20, anchor="n")

restart = tk.Button(master, text="Начать заново", command=prepare_and_start, font=("Oswald", 20))
restart.pack()

player_pic = tk.PhotoImage(file="material/homo_sal.gif")
exit_pic = tk.PhotoImage(file="material/terminal.gif")
durka_pic = tk.PhotoImage(file="material/durka.gif")
enemy_pic = tk.PhotoImage(file="material/durdoctor.gif")
sal_pic = tk.PhotoImage(file="material/sal.gif")
end_pic = tk.PhotoImage(file="material/end.png")
end_pic2 = tk.PhotoImage(file="material/end2.png")
win_pic = tk.PhotoImage(file="material/win.png")

pygame.init()
play_music()
prepare_and_start()
master.mainloop()
pygame.quit()
